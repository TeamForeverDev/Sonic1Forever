# S1F-The-Final-Forever
Attempt at finishing up S1F

# CHANGELONG
------------
NEW CONTENT
------------
* Added the Sound Test featuring the original band, available in the Extras
* Added the Team Credits in the Extras
* Added the special Toy Show level inspired by the Toyko Toy Show demo

------------
BUGFIXES/UPDATES
------------ 
* Updated Super Sonic Sprites to better match the Sonic 1 Style
* Updated Knuckles Continue Sprites


------------
PLANNED
------------ 
* Mod Menu smoothly reloading upon exiting its menu
* Jungle Zone Mode
